package com.shalenamma.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.shalenamma.data.model.MealUpdate

@Dao
interface MealDao {

    @Query("SELECT * FROM meal_updates ORDER BY postedAt DESC")
    fun getAll(): LiveData<List<MealUpdate>>

    @Query("SELECT * FROM meal_updates WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getByDate(dateKey: String): MealUpdate?

    @Query("SELECT * FROM meal_updates ORDER BY postedAt DESC LIMIT 1")
    fun getLatest(): LiveData<MealUpdate?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(meal: MealUpdate)

    @Update
    suspend fun update(meal: MealUpdate)

    @Delete
    suspend fun delete(meal: MealUpdate)

    @Query("SELECT COUNT(*) FROM meal_updates")
    suspend fun count(): Int
}
