package com.shalenamma.data.db

// Room supports Boolean natively since Room 2.1+
// No custom type converters needed for this project.
class Converters
