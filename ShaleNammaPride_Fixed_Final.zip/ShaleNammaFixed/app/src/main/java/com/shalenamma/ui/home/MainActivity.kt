package com.shalenamma.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.shalenamma.ShaleNammaApp
import com.shalenamma.databinding.ActivityMainBinding
import com.shalenamma.ui.admin.AdminActivity
import com.shalenamma.ui.facility.FacilityTourActivity
import com.shalenamma.ui.feedback.FeedbackActivity
import com.shalenamma.ui.meal.DailyMealActivity
import com.shalenamma.ui.stars.StudentStarsActivity
import com.shalenamma.utils.ViewModelFactory
import com.shalenamma.utils.toDateString

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var vm: HomeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val factory = ViewModelFactory((application as ShaleNammaApp).repository)
        vm = ViewModelProvider(this, factory)[HomeViewModel::class.java]

        setupObservers()
        setupClicks()
    }

    private fun setupObservers() {
        vm.schoolInfo.observe(this) { info ->
            if (info != null) {
                binding.tvSchoolName.text = info.schoolName
                binding.tvSchoolNameKn.text = info.schoolNameKn
                binding.tvVillage.text = "📍 ${info.village}, ${info.taluk}, ${info.district}"
                binding.tvPrincipal.text = "Principal: ${info.principalName}"
                binding.tvStudentCount.text = "👩‍🎓 ${info.totalStudents} Students"
                binding.tvTeacherCount.text = "👨‍🏫 ${info.totalTeachers} Teachers"
                binding.tvMotto.text = "\"${info.mottoKn}\""
            }
        }

        vm.latestMeal.observe(this) { meal ->
            if (meal != null) {
                binding.cardMealPreview.visibility = View.VISIBLE
                binding.tvMealPreview.text = meal.menuKannada.ifEmpty { meal.menuEnglish }
                binding.tvMealDate.text = meal.postedAt.toDateString()
            } else {
                binding.cardMealPreview.visibility = View.GONE
            }
        }

        vm.recentStars.observe(this) { stars ->
            if (stars.isNotEmpty()) {
                binding.tvLatestStar.text = "⭐ ${stars.first().studentName} — ${stars.first().achievement}"
            }
        }

        vm.feedbackCount.observe(this) { count ->
            binding.tvFeedbackCount.text = "$count feedbacks received"
        }

        vm.avgRating.observe(this) { avg ->
            binding.tvAvgRating.text = if (avg != null) "★ ${"%.1f".format(avg)} avg rating" else "No ratings yet"
        }
    }

    private fun setupClicks() {
        binding.cardMeal.setOnClickListener       { startActivity(Intent(this, DailyMealActivity::class.java)) }
        binding.cardFacility.setOnClickListener   { startActivity(Intent(this, FacilityTourActivity::class.java)) }
        binding.cardStars.setOnClickListener      { startActivity(Intent(this, StudentStarsActivity::class.java)) }
        binding.cardFeedback.setOnClickListener   { startActivity(Intent(this, FeedbackActivity::class.java)) }
        binding.fabAdmin.setOnClickListener       { startActivity(Intent(this, AdminActivity::class.java)) }
        binding.cardMealPreview.setOnClickListener { startActivity(Intent(this, DailyMealActivity::class.java)) }
    }
}
