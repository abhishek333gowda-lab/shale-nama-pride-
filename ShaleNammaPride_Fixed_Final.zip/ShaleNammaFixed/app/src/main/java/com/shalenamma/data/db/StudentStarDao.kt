package com.shalenamma.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.shalenamma.data.model.StudentStar

@Dao
interface StudentStarDao {

    @Query("SELECT * FROM student_stars ORDER BY addedAt DESC")
    fun getAll(): LiveData<List<StudentStar>>

    @Query("SELECT * FROM student_stars WHERE category = :cat ORDER BY addedAt DESC")
    fun getByCategory(cat: String): LiveData<List<StudentStar>>

    @Query("SELECT * FROM student_stars ORDER BY addedAt DESC LIMIT 5")
    fun getRecent(): LiveData<List<StudentStar>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(star: StudentStar)

    @Update
    suspend fun update(star: StudentStar)

    @Delete
    suspend fun delete(star: StudentStar)

    @Query("SELECT COUNT(*) FROM student_stars")
    suspend fun count(): Int
}
