package com.shalenamma.ui.meal

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.shalenamma.data.model.MealUpdate
import com.shalenamma.databinding.ItemMealBinding
import com.shalenamma.utils.toDateString

class MealAdapter(
    private val onDelete: (MealUpdate) -> Unit
) : ListAdapter<MealUpdate, MealAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemMealBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    inner class VH(private val b: ItemMealBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(meal: MealUpdate) {
            b.tvDateKey.text = "📅 ${meal.dateKey}"
            b.tvMenuEn.text = meal.menuEnglish.ifEmpty { "—" }
            b.tvMenuKn.text = meal.menuKannada.ifEmpty { "—" }
            b.tvPostedAt.text = meal.postedAt.toDateString()
            b.btnDelete.setOnClickListener { onDelete(meal) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<MealUpdate>() {
            override fun areItemsTheSame(o: MealUpdate, n: MealUpdate) = o.id == n.id
            override fun areContentsTheSame(o: MealUpdate, n: MealUpdate) = o == n
        }
    }
}
