package com.shalenamma.utils

import android.content.Context
import android.widget.Toast
import com.shalenamma.data.model.FacilityCategory
import com.shalenamma.data.model.FeedbackType
import com.shalenamma.data.model.StarCategory
import java.text.SimpleDateFormat
import java.util.*

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

fun Long.toDateString(): String =
    SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(this))

fun todayKey(): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

fun String.toFacilityCategoryDisplay(): String =
    FacilityCategory.values().firstOrNull { it.name == this }?.displayEn ?: this

fun String.toStarCategoryDisplay(): String =
    StarCategory.values().firstOrNull { it.name == this }?.displayEn ?: this

fun String.toFeedbackTypeDisplay(): String =
    FeedbackType.values().firstOrNull { it.name == this }?.displayEn ?: this
