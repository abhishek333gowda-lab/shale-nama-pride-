package com.shalenamma.ui.stars

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shalenamma.data.model.StudentStar
import com.shalenamma.data.repository.ShaleNammaRepository
import kotlinx.coroutines.launch

class StarsViewModel(private val repo: ShaleNammaRepository) : ViewModel() {
    val allStars = repo.allStars

    fun save(star: StudentStar) { viewModelScope.launch { repo.saveStar(star) } }
    fun delete(star: StudentStar) { viewModelScope.launch { repo.deleteStar(star) } }
}
