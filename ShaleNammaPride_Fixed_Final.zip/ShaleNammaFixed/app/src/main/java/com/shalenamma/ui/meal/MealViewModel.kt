package com.shalenamma.ui.meal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shalenamma.data.model.MealUpdate
import com.shalenamma.data.repository.ShaleNammaRepository
import kotlinx.coroutines.launch

class MealViewModel(private val repo: ShaleNammaRepository) : ViewModel() {
    val allMeals = repo.allMeals

    fun saveMeal(meal: MealUpdate) {
        viewModelScope.launch { repo.saveMeal(meal) }
    }

    fun deleteMeal(meal: MealUpdate) {
        viewModelScope.launch { repo.deleteMeal(meal) }
    }
}
