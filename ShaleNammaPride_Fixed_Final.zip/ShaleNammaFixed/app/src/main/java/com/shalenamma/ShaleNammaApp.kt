package com.shalenamma

import android.app.Application
import com.shalenamma.data.db.ShaleNammaDatabase
import com.shalenamma.data.repository.ShaleNammaRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ShaleNammaApp : Application() {
    val database by lazy { ShaleNammaDatabase.getDatabase(this) }
    val repository by lazy {
        ShaleNammaRepository(
            database.mealDao(),
            database.facilityDao(),
            database.studentStarDao(),
            database.feedbackDao(),
            database.schoolInfoDao()
        )
    }

    override fun onCreate() {
        super.onCreate()
        // Seed default data on first launch regardless of which Activity opens first
        CoroutineScope(Dispatchers.IO).launch {
            repository.seedIfEmpty()
        }
    }
}
