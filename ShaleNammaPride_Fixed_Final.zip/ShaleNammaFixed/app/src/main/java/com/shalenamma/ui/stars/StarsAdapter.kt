package com.shalenamma.ui.stars

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.shalenamma.R
import com.shalenamma.data.model.StudentStar
import com.shalenamma.databinding.ItemStarBinding
import com.shalenamma.utils.toStarCategoryDisplay

class StarsAdapter(
    private val onDelete: (StudentStar) -> Unit
) : ListAdapter<StudentStar, StarsAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemStarBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    inner class VH(private val b: ItemStarBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(s: StudentStar) {
            b.tvStudentName.text = s.studentName
            b.tvStudentNameKn.text = s.studentNameKn.ifEmpty { "" }
            b.tvClassName.text = s.className
            b.tvAchievement.text = s.achievement
            b.tvAchievementKn.text = s.achievementKn.ifEmpty { "" }
            b.tvCategory.text = s.category.toStarCategoryDisplay()
            b.tvDate.text = "📅 ${s.dateAwarded}"
            if (s.photoUri.isNotEmpty()) {
                Glide.with(b.root.context).load(s.photoUri)
                    .circleCrop().placeholder(R.drawable.ic_star_person).into(b.ivStudentPhoto)
            } else {
                b.ivStudentPhoto.setImageResource(R.drawable.ic_star_person)
            }
            b.btnDelete.setOnClickListener { onDelete(s) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<StudentStar>() {
            override fun areItemsTheSame(o: StudentStar, n: StudentStar) = o.id == n.id
            override fun areContentsTheSame(o: StudentStar, n: StudentStar) = o == n
        }
    }
}
