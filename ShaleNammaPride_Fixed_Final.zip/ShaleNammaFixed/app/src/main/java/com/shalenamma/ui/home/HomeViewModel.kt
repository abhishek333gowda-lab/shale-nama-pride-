package com.shalenamma.ui.home

import androidx.lifecycle.ViewModel
import com.shalenamma.data.repository.ShaleNammaRepository

class HomeViewModel(private val repo: ShaleNammaRepository) : ViewModel() {
    val schoolInfo    = repo.schoolInfo
    val latestMeal    = repo.latestMeal
    val recentStars   = repo.recentStars
    val feedbackCount = repo.feedbackCount
    val avgRating     = repo.averageRating
}
