package com.shalenamma.ui.facility

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.shalenamma.R
import com.shalenamma.data.model.FacilityPhoto
import com.shalenamma.databinding.ItemFacilityBinding
import com.shalenamma.utils.toFacilityCategoryDisplay

class FacilityAdapter(
    private val onDelete: (FacilityPhoto) -> Unit
) : ListAdapter<FacilityPhoto, FacilityAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemFacilityBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    inner class VH(private val b: ItemFacilityBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(f: FacilityPhoto) {
            b.tvCaptionEn.text = f.captionEnglish
            b.tvCaptionKn.text = f.captionKannada.ifEmpty { "" }
            b.tvCategory.text = f.category.toFacilityCategoryDisplay()
            if (f.photoUri.isNotEmpty()) {
                Glide.with(b.root.context).load(f.photoUri)
                    .placeholder(R.drawable.ic_school).into(b.ivPhoto)
            } else {
                b.ivPhoto.setImageResource(R.drawable.ic_school)
            }
            b.btnDelete.setOnClickListener { onDelete(f) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<FacilityPhoto>() {
            override fun areItemsTheSame(o: FacilityPhoto, n: FacilityPhoto) = o.id == n.id
            override fun areContentsTheSame(o: FacilityPhoto, n: FacilityPhoto) = o == n
        }
    }
}
