package com.shalenamma.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.shalenamma.data.model.*

@TypeConverters(Converters::class)
@Database(
    entities = [MealUpdate::class, FacilityPhoto::class, StudentStar::class,
                Feedback::class, SchoolInfo::class],
    version = 1,
    exportSchema = false
)
abstract class ShaleNammaDatabase : RoomDatabase() {

    abstract fun mealDao(): MealDao
    abstract fun facilityDao(): FacilityDao
    abstract fun studentStarDao(): StudentStarDao
    abstract fun feedbackDao(): FeedbackDao
    abstract fun schoolInfoDao(): SchoolInfoDao

    companion object {
        @Volatile private var INSTANCE: ShaleNammaDatabase? = null

        fun getDatabase(context: Context): ShaleNammaDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    ShaleNammaDatabase::class.java,
                    "shale_namma_db"
                ).build().also { INSTANCE = it }
            }
    }
}
