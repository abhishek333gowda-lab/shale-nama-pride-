package com.shalenamma.ui.admin

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.shalenamma.ShaleNammaApp
import com.shalenamma.data.model.SchoolInfo
import com.shalenamma.databinding.ActivityAdminBinding
import com.shalenamma.ui.facility.FacilityTourActivity
import com.shalenamma.ui.meal.DailyMealActivity
import com.shalenamma.ui.stars.StudentStarsActivity
import com.shalenamma.utils.ViewModelFactory
import com.shalenamma.utils.toast

class AdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminBinding
    private lateinit var vm: AdminViewModel
    private var currentInfo: SchoolInfo? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "⚙️ Admin Panel"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory((application as ShaleNammaApp).repository)
        vm = ViewModelProvider(this, factory)[AdminViewModel::class.java]

        vm.schoolInfo.observe(this) { info ->
            currentInfo = info
            if (info != null) {
                binding.etSchoolName.setText(info.schoolName)
                binding.etSchoolNameKn.setText(info.schoolNameKn)
                binding.etVillage.setText(info.village)
                binding.etTaluk.setText(info.taluk)
                binding.etDistrict.setText(info.district)
                binding.etPrincipal.setText(info.principalName)
                binding.etPhone.setText(info.phoneNumber)
                binding.etStudents.setText(info.totalStudents.toString())
                binding.etTeachers.setText(info.totalTeachers.toString())
                binding.etEstablished.setText(info.established)
                binding.etMotto.setText(info.motto)
                binding.etMottoKn.setText(info.mottoKn)
            }
        }

        vm.allMeals.observe(this) { meals ->
            binding.tvMealCount.text = "📅 ${meals.size} meal entries"
        }

        vm.allFeedback.observe(this) { list ->
            binding.tvFeedbackCount.text = "💬 ${list.size} feedbacks"
        }

        binding.btnSaveSchool.setOnClickListener { saveSchoolInfo() }
        binding.btnManageMeals.setOnClickListener { startActivity(Intent(this, DailyMealActivity::class.java)) }
        binding.btnManageFacility.setOnClickListener { startActivity(Intent(this, FacilityTourActivity::class.java)) }
        binding.btnManageStars.setOnClickListener { startActivity(Intent(this, StudentStarsActivity::class.java)) }
    }

    private fun saveSchoolInfo() {
        val name = binding.etSchoolName.text.toString().trim()
        if (name.isEmpty()) { toast("School name is required"); return }

        val info = SchoolInfo(
            id = 1,
            schoolName = name,
            schoolNameKn = binding.etSchoolNameKn.text.toString().trim(),
            village = binding.etVillage.text.toString().trim(),
            taluk = binding.etTaluk.text.toString().trim(),
            district = binding.etDistrict.text.toString().trim(),
            principalName = binding.etPrincipal.text.toString().trim(),
            phoneNumber = binding.etPhone.text.toString().trim(),
            totalStudents = binding.etStudents.text.toString().toIntOrNull() ?: 0,
            totalTeachers = binding.etTeachers.text.toString().toIntOrNull() ?: 0,
            established = binding.etEstablished.text.toString().trim(),
            motto = binding.etMotto.text.toString().trim(),
            mottoKn = binding.etMottoKn.text.toString().trim()
        )
        vm.saveSchoolInfo(info)
        toast("✅ School info saved!")
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
