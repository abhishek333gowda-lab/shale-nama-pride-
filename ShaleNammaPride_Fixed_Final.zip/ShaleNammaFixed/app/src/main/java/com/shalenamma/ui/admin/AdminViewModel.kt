package com.shalenamma.ui.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shalenamma.data.model.SchoolInfo
import com.shalenamma.data.repository.ShaleNammaRepository
import kotlinx.coroutines.launch

class AdminViewModel(private val repo: ShaleNammaRepository) : ViewModel() {
    val schoolInfo  = repo.schoolInfo
    val allMeals    = repo.allMeals
    val allFeedback = repo.allFeedback

    fun saveSchoolInfo(info: SchoolInfo) {
        viewModelScope.launch { repo.saveSchoolInfo(info) }
    }
}
