package com.shalenamma.ui.feedback

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.shalenamma.ShaleNammaApp
import com.shalenamma.data.model.Feedback
import com.shalenamma.data.model.FeedbackType
import com.shalenamma.databinding.ActivityFeedbackBinding
import com.shalenamma.utils.ViewModelFactory
import com.shalenamma.utils.toast

class FeedbackActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFeedbackBinding
    private lateinit var vm: FeedbackViewModel
    private lateinit var adapter: FeedbackAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "💬 Feedback"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory((application as ShaleNammaApp).repository)
        vm = ViewModelProvider(this, factory)[FeedbackViewModel::class.java]

        val types = FeedbackType.values().map { it.displayEn }
        binding.spinnerType.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)

        adapter = FeedbackAdapter()
        binding.rvFeedback.layoutManager = LinearLayoutManager(this)
        binding.rvFeedback.adapter = adapter

        vm.allFeedback.observe(this) { list ->
            adapter.submitList(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }

        vm.count.observe(this) { count ->
            binding.tvCount.text = "$count community feedbacks"
        }

        vm.avgRating.observe(this) { avg ->
            binding.tvAvgRating.text =
                if (avg != null) "★ ${"%.1f".format(avg)} average" else "No ratings yet"
        }

        binding.btnSubmit.setOnClickListener { submitFeedback() }
    }

    private fun submitFeedback() {
        val name    = binding.etName.text.toString().trim()
        val message = binding.etMessage.text.toString().trim()
        val isAnon  = binding.cbAnonymous.isChecked
        val rating  = binding.ratingBar.rating.toInt().coerceIn(1, 5)
        val type    = FeedbackType.values()[binding.spinnerType.selectedItemPosition].name

        if (message.isEmpty()) { toast("Please write your feedback"); return }
        if (!isAnon && name.isEmpty()) { toast("Enter your name or check Anonymous"); return }

        vm.submit(Feedback(
            senderName  = if (isAnon) "Anonymous" else name,
            senderType  = type,
            message     = message,
            rating      = rating,
            isAnonymous = isAnon
        ))

        binding.etName.setText("")
        binding.etMessage.setText("")
        binding.ratingBar.rating = 5f
        binding.cbAnonymous.isChecked = false
        toast("✅ Thank you for your feedback!")
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
