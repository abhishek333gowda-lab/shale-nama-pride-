package com.shalenamma.ui.feedback

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.shalenamma.data.model.Feedback
import com.shalenamma.databinding.ItemFeedbackBinding
import com.shalenamma.utils.toDateString
import com.shalenamma.utils.toFeedbackTypeDisplay

class FeedbackAdapter : ListAdapter<Feedback, FeedbackAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemFeedbackBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    inner class VH(private val b: ItemFeedbackBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(fb: Feedback) {
            b.tvSender.text = if (fb.isAnonymous) "👤 Anonymous" else "👤 ${fb.senderName}"
            b.tvType.text = fb.senderType.toFeedbackTypeDisplay()
            b.tvMessage.text = fb.message
            b.tvRating.text = "★".repeat(fb.rating) + "☆".repeat(5 - fb.rating)
            b.tvDate.text = fb.submittedAt.toDateString()
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Feedback>() {
            override fun areItemsTheSame(o: Feedback, n: Feedback) = o.id == n.id
            override fun areContentsTheSame(o: Feedback, n: Feedback) = o == n
        }
    }
}
