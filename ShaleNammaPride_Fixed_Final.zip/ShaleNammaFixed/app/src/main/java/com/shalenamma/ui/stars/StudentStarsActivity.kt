package com.shalenamma.ui.stars

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.shalenamma.ShaleNammaApp
import com.shalenamma.R
import com.shalenamma.data.model.StarCategory
import com.shalenamma.data.model.StudentStar
import com.shalenamma.databinding.ActivityStudentStarsBinding
import com.shalenamma.utils.ViewModelFactory
import com.shalenamma.utils.toast
import com.shalenamma.utils.todayKey

class StudentStarsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStudentStarsBinding
    private lateinit var vm: StarsViewModel
    private lateinit var adapter: StarsAdapter
    private var pendingPhotoUri = ""

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { pendingPhotoUri = it.toString() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStudentStarsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "⭐ Student Stars"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory((application as ShaleNammaApp).repository)
        vm = ViewModelProvider(this, factory)[StarsViewModel::class.java]

        adapter = StarsAdapter(
            onDelete = { star ->
                AlertDialog.Builder(this)
                    .setTitle("Remove star?")
                    .setPositiveButton("Remove") { _, _ -> vm.delete(star); toast("Removed") }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvStars.layoutManager = LinearLayoutManager(this)
        binding.rvStars.adapter = adapter

        vm.allStars.observe(this) { list ->
            adapter.submitList(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.btnAddStar.setOnClickListener { showAddStarDialog() }
    }

    private fun showAddStarDialog() {
        pendingPhotoUri = ""
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_star, null)
        val etName    = view.findViewById<EditText>(R.id.etStudentName)
        val etNameKn  = view.findViewById<EditText>(R.id.etStudentNameKn)
        val etClass   = view.findViewById<EditText>(R.id.etClassName)
        val etAchieve = view.findViewById<EditText>(R.id.etAchievement)
        val etAchKn   = view.findViewById<EditText>(R.id.etAchievementKn)
        val spinner   = view.findViewById<Spinner>(R.id.spinnerStarCategory)
        val btnPick   = view.findViewById<android.widget.Button>(R.id.btnPickPhoto)

        val cats = StarCategory.values().map { it.displayEn }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
        btnPick.setOnClickListener { pickImage.launch("image/*") }

        AlertDialog.Builder(this)
            .setTitle("Add Student Star ⭐")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val name    = etName.text.toString().trim()
                val achieve = etAchieve.text.toString().trim()
                if (name.isEmpty() || achieve.isEmpty()) {
                    toast("Name and achievement are required"); return@setPositiveButton
                }
                val cat = StarCategory.values()[spinner.selectedItemPosition].name
                vm.save(StudentStar(
                    studentName    = name,
                    studentNameKn  = etNameKn.text.toString().trim(),
                    className      = etClass.text.toString().trim(),
                    achievement    = achieve,
                    achievementKn  = etAchKn.text.toString().trim(),
                    category       = cat,
                    photoUri       = pendingPhotoUri,
                    dateAwarded    = todayKey()
                ))
                toast("⭐ Student star added!")
            }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
