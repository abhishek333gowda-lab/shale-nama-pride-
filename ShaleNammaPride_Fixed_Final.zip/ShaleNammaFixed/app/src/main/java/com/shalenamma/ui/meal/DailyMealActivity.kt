package com.shalenamma.ui.meal

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.shalenamma.ShaleNammaApp
import com.shalenamma.R
import com.shalenamma.data.model.MealUpdate
import com.shalenamma.databinding.ActivityDailyMealBinding
import com.shalenamma.utils.ViewModelFactory
import com.shalenamma.utils.toast
import com.shalenamma.utils.todayKey

class DailyMealActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDailyMealBinding
    private lateinit var vm: MealViewModel
    private lateinit var adapter: MealAdapter
    private var selectedPhotoUri = ""

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { selectedPhotoUri = it.toString() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDailyMealBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "🍱 Daily Meal Menu"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory((application as ShaleNammaApp).repository)
        vm = ViewModelProvider(this, factory)[MealViewModel::class.java]

        adapter = MealAdapter(
            onDelete = { meal ->
                AlertDialog.Builder(this)
                    .setTitle("Delete meal entry?")
                    .setPositiveButton("Delete") { _, _ -> vm.deleteMeal(meal); toast("Deleted") }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvMeals.layoutManager = LinearLayoutManager(this)
        binding.rvMeals.adapter = adapter

        vm.allMeals.observe(this) { meals ->
            adapter.submitList(meals)
            binding.tvEmpty.visibility = if (meals.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.btnAddMeal.setOnClickListener { showAddMealDialog() }
    }

    private fun showAddMealDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_meal, null)
        val etEn = view.findViewById<EditText>(R.id.etMenuEnglish)
        val etKn = view.findViewById<EditText>(R.id.etMenuKannada)

        AlertDialog.Builder(this)
            .setTitle("Update Today's Menu")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val menuEn = etEn.text.toString().trim()
                val menuKn = etKn.text.toString().trim()
                if (menuEn.isEmpty() && menuKn.isEmpty()) {
                    toast("Please enter the menu"); return@setPositiveButton
                }
                vm.saveMeal(MealUpdate(
                    dateKey = todayKey(),
                    menuEnglish = menuEn,
                    menuKannada = menuKn,
                    photoUri = selectedPhotoUri
                ))
                toast("✅ Menu updated!")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
