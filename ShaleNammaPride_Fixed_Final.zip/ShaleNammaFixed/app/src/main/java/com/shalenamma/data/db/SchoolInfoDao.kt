package com.shalenamma.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.shalenamma.data.model.SchoolInfo

@Dao
interface SchoolInfoDao {

    @Query("SELECT * FROM school_info WHERE id = 1 LIMIT 1")
    fun get(): LiveData<SchoolInfo?>

    @Query("SELECT * FROM school_info WHERE id = 1 LIMIT 1")
    suspend fun getOnce(): SchoolInfo?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(info: SchoolInfo)

    @Update
    suspend fun update(info: SchoolInfo)
}
