package com.shalenamma.data.repository

import com.shalenamma.data.db.*
import com.shalenamma.data.model.*
import java.text.SimpleDateFormat
import java.util.*

class ShaleNammaRepository(
    private val mealDao: MealDao,
    private val facilityDao: FacilityDao,
    private val starDao: StudentStarDao,
    private val feedbackDao: FeedbackDao,
    private val schoolInfoDao: SchoolInfoDao
) {
    // ── School Info ──────────────────────────────────────────────
    val schoolInfo = schoolInfoDao.get()

    suspend fun saveSchoolInfo(info: SchoolInfo) {
        if (schoolInfoDao.getOnce() == null) schoolInfoDao.insert(info)
        else schoolInfoDao.update(info)
    }

    // ── Meals ────────────────────────────────────────────────────
    val allMeals   = mealDao.getAll()
    val latestMeal = mealDao.getLatest()

    suspend fun saveMeal(meal: MealUpdate) {
        val existing = mealDao.getByDate(meal.dateKey)
        if (existing != null) mealDao.update(meal.copy(id = existing.id))
        else mealDao.insert(meal)
    }

    suspend fun deleteMeal(meal: MealUpdate) = mealDao.delete(meal)

    // ── Facilities ───────────────────────────────────────────────
    val allFacilities = facilityDao.getAll()
    fun facilitiesByCategory(cat: String) = facilityDao.getByCategory(cat)
    suspend fun saveFacility(photo: FacilityPhoto) = facilityDao.insert(photo)
    suspend fun updateFacility(photo: FacilityPhoto) = facilityDao.update(photo)
    suspend fun deleteFacility(photo: FacilityPhoto) = facilityDao.delete(photo)

    // ── Student Stars ────────────────────────────────────────────
    val allStars   = starDao.getAll()
    val recentStars = starDao.getRecent()
    fun starsByCategory(cat: String) = starDao.getByCategory(cat)
    suspend fun saveStar(star: StudentStar) = starDao.insert(star)
    suspend fun updateStar(star: StudentStar) = starDao.update(star)
    suspend fun deleteStar(star: StudentStar) = starDao.delete(star)

    // ── Feedback ─────────────────────────────────────────────────
    val allFeedback  = feedbackDao.getAll()
    val feedbackCount = feedbackDao.getCount()
    val averageRating = feedbackDao.getAverageRating()
    suspend fun submitFeedback(fb: Feedback) = feedbackDao.insert(fb)
    suspend fun deleteFeedback(fb: Feedback) = feedbackDao.delete(fb)

    // ── Seeder ───────────────────────────────────────────────────
    suspend fun seedIfEmpty() {
        if (schoolInfoDao.getOnce() == null) {
            schoolInfoDao.insert(SchoolInfo(
                schoolName    = "Sri Basaveshwara Government Higher Primary School",
                schoolNameKn  = "ಶ್ರೀ ಬಸವೇಶ್ವರ ಸರ್ಕಾರಿ ಉನ್ನತ ಪ್ರಾಥಮಿಕ ಶಾಲೆ",
                village       = "Kundur",
                taluk         = "Yadgir",
                district      = "Yadgir",
                principalName = "Smt. Lalitha Devi K",
                phoneNumber   = "9886001234",
                totalStudents = 312,
                totalTeachers = 14,
                established   = "1968",
                motto         = "Knowledge is Light",
                mottoKn       = "ಜ್ಞಾನವೇ ಬೆಳಕು"
            ))
        }

        if (mealDao.count() == 0) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val today     = sdf.format(Date())
            val yesterday = sdf.format(Date(System.currentTimeMillis() - 86_400_000L))
            mealDao.insert(MealUpdate(dateKey = today,
                menuEnglish = "Rice, Sambar, Beans Palya, Chapati, Banana",
                menuKannada = "ಅನ್ನ, ಸಾಂಬಾರ್, ಬೀನ್ಸ್ ಪಲ್ಯ, ಚಪಾತಿ, ಬಾಳೆಹಣ್ಣು"))
            mealDao.insert(MealUpdate(dateKey = yesterday,
                menuEnglish = "Rice, Rasam, Potato Fry, Roti, Egg",
                menuKannada = "ಅನ್ನ, ರಸಂ, ಆಲೂ ಫ್ರೈ, ರೊಟ್ಟಿ, ಮೊಟ್ಟೆ"))
        }

        if (facilityDao.count() == 0) {
            facilityDao.insert(FacilityPhoto(category = FacilityCategory.LAB.name,
                captionEnglish = "Fully Equipped Science Lab",
                captionKannada = "ಸಂಪೂರ್ಣ ವಿಜ್ಞಾನ ಪ್ರಯೋಗಾಲಯ"))
            facilityDao.insert(FacilityPhoto(category = FacilityCategory.LIBRARY.name,
                captionEnglish = "Library with 2000+ Books",
                captionKannada = "2000+ ಪುಸ್ತಕಗಳ ಗ್ರಂಥಾಲಯ"))
            facilityDao.insert(FacilityPhoto(category = FacilityCategory.SPORTS.name,
                captionEnglish = "Kabaddi & Cricket Ground",
                captionKannada = "ಕಬಡ್ಡಿ ಮತ್ತು ಕ್ರಿಕೆಟ್ ಮೈದಾನ"))
            facilityDao.insert(FacilityPhoto(category = FacilityCategory.CLASSROOM.name,
                captionEnglish = "Smart Classroom with Projector",
                captionKannada = "ಪ್ರೊಜೆಕ್ಟರ್ ಸಹಿತ ಸ್ಮಾರ್ಟ್ ತರಗತಿ"))
            facilityDao.insert(FacilityPhoto(category = FacilityCategory.TOILET.name,
                captionEnglish = "Clean Separate Toilets for Boys & Girls",
                captionKannada = "ಹುಡುಗರು ಮತ್ತು ಹುಡುಗಿಯರಿಗೆ ಶೌಚಾಲಯ"))
        }

        if (starDao.count() == 0) {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            starDao.insert(StudentStar(studentName = "Asha Kumari",
                studentNameKn = "ಆಶಾ ಕುಮಾರಿ", className = "Class 7B",
                category = StarCategory.WEEK.name,
                achievement = "Scored 98% in Science exam",
                achievementKn = "ವಿಜ್ಞಾನ ಪರೀಕ್ಷೆಯಲ್ಲಿ 98% ಗಳಿಸಿದರು",
                dateAwarded = today))
            starDao.insert(StudentStar(studentName = "Ravi Naik",
                studentNameKn = "ರವಿ ನಾಯ್ಕ", className = "Class 8A",
                category = StarCategory.SPORTS.name,
                achievement = "District Kabaddi Champion",
                achievementKn = "ಜಿಲ್ಲಾ ಕಬಡ್ಡಿ ಚಾಂಪಿಯನ್",
                dateAwarded = today))
            starDao.insert(StudentStar(studentName = "Priya S",
                studentNameKn = "ಪ್ರಿಯಾ ಎಸ್", className = "Class 6C",
                category = StarCategory.CULTURE.name,
                achievement = "Won 1st prize in state drawing competition",
                achievementKn = "ರಾಜ್ಯ ಚಿತ್ರಕಲಾ ಸ್ಪರ್ಧೆಯಲ್ಲಿ ಪ್ರಥಮ ಸ್ಥಾನ",
                dateAwarded = today))
        }

        if (feedbackDao.count() == 0) {
            feedbackDao.insert(Feedback(senderName = "Suresh (Parent)",
                senderType = FeedbackType.PARENT.name,
                message = "The daily meal update on this app is very helpful. Now I know what my child eats every day!",
                rating = 5))
            feedbackDao.insert(Feedback(senderName = "Kavitha (Teacher)",
                senderType = FeedbackType.TEACHER.name,
                message = "Great initiative! Parents are now more engaged with school activities.",
                rating = 4))
            feedbackDao.insert(Feedback(senderName = "Anonymous",
                senderType = FeedbackType.PARENT.name,
                message = "Please add English medium option for menus. Overall very good app.",
                rating = 4, isAnonymous = true))
        }
    }
}
