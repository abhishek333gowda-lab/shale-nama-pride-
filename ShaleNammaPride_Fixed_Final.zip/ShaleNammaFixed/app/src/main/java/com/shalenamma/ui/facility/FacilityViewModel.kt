package com.shalenamma.ui.facility

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shalenamma.data.model.FacilityPhoto
import com.shalenamma.data.repository.ShaleNammaRepository
import kotlinx.coroutines.launch

class FacilityViewModel(private val repo: ShaleNammaRepository) : ViewModel() {
    val allFacilities = repo.allFacilities

    fun save(photo: FacilityPhoto) { viewModelScope.launch { repo.saveFacility(photo) } }
    fun update(photo: FacilityPhoto) { viewModelScope.launch { repo.updateFacility(photo) } }
    fun delete(photo: FacilityPhoto) { viewModelScope.launch { repo.deleteFacility(photo) } }
}
