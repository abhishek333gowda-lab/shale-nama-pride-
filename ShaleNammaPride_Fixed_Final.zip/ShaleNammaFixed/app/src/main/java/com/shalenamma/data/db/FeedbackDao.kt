package com.shalenamma.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.shalenamma.data.model.Feedback

@Dao
interface FeedbackDao {

    @Query("SELECT * FROM feedback ORDER BY submittedAt DESC")
    fun getAll(): LiveData<List<Feedback>>

    @Query("SELECT AVG(rating) FROM feedback")
    fun getAverageRating(): LiveData<Float?>

    @Query("SELECT COUNT(*) FROM feedback")
    fun getCount(): LiveData<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(feedback: Feedback)

    @Delete
    suspend fun delete(feedback: Feedback)

    @Query("SELECT COUNT(*) FROM feedback")
    suspend fun count(): Int
}
