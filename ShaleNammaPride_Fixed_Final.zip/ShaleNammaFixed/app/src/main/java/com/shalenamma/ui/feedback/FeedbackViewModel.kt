package com.shalenamma.ui.feedback

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shalenamma.data.model.Feedback
import com.shalenamma.data.repository.ShaleNammaRepository
import kotlinx.coroutines.launch

class FeedbackViewModel(private val repo: ShaleNammaRepository) : ViewModel() {
    val allFeedback = repo.allFeedback
    val count       = repo.feedbackCount
    val avgRating   = repo.averageRating

    fun submit(fb: Feedback) { viewModelScope.launch { repo.submitFeedback(fb) } }
    fun delete(fb: Feedback) { viewModelScope.launch { repo.deleteFeedback(fb) } }
}
