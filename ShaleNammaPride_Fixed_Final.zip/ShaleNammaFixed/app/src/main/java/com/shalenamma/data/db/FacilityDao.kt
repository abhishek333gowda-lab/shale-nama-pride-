package com.shalenamma.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.shalenamma.data.model.FacilityPhoto

@Dao
interface FacilityDao {

    @Query("SELECT * FROM facility_photos ORDER BY addedAt DESC")
    fun getAll(): LiveData<List<FacilityPhoto>>

    @Query("SELECT * FROM facility_photos WHERE category = :cat ORDER BY addedAt DESC")
    fun getByCategory(cat: String): LiveData<List<FacilityPhoto>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(photo: FacilityPhoto)

    @Update
    suspend fun update(photo: FacilityPhoto)

    @Delete
    suspend fun delete(photo: FacilityPhoto)

    @Query("SELECT COUNT(*) FROM facility_photos")
    suspend fun count(): Int
}
