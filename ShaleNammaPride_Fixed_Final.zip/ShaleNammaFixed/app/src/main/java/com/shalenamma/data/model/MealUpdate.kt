package com.shalenamma.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "meal_updates")
data class MealUpdate(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dateKey: String = "",          // "yyyy-MM-dd" — enforces one update per day
    val menuEnglish: String = "",
    val menuKannada: String = "",
    val photoUri: String = "",
    val postedAt: Long = System.currentTimeMillis()
)
