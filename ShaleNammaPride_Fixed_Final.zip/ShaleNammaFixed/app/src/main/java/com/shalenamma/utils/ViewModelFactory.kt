package com.shalenamma.utils

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.shalenamma.data.repository.ShaleNammaRepository
import com.shalenamma.ui.admin.AdminViewModel
import com.shalenamma.ui.facility.FacilityViewModel
import com.shalenamma.ui.feedback.FeedbackViewModel
import com.shalenamma.ui.home.HomeViewModel
import com.shalenamma.ui.meal.MealViewModel
import com.shalenamma.ui.stars.StarsViewModel

class ViewModelFactory(private val repo: ShaleNammaRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(HomeViewModel::class.java)     -> HomeViewModel(repo) as T
        modelClass.isAssignableFrom(MealViewModel::class.java)     -> MealViewModel(repo) as T
        modelClass.isAssignableFrom(FacilityViewModel::class.java) -> FacilityViewModel(repo) as T
        modelClass.isAssignableFrom(StarsViewModel::class.java)    -> StarsViewModel(repo) as T
        modelClass.isAssignableFrom(FeedbackViewModel::class.java) -> FeedbackViewModel(repo) as T
        modelClass.isAssignableFrom(AdminViewModel::class.java)    -> AdminViewModel(repo) as T
        else -> throw IllegalArgumentException("Unknown VM: ${modelClass.name}")
    }
}
