package com.shalenamma.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class FacilityCategory(val displayEn: String, val displayKn: String) {
    LAB("Science Lab", "ವಿಜ್ಞಾನ ಲ್ಯಾಬ್"),
    LIBRARY("Library", "ಗ್ರಂಥಾಲಯ"),
    SPORTS("Sports Ground", "ಕ್ರೀಡಾಂಗಣ"),
    CLASSROOM("Smart Classroom", "ಸ್ಮಾರ್ಟ್ ತರಗತಿ"),
    TOILET("Clean Toilets", "ಶೌಚಾಲಯ"),
    OTHER("Other", "ಇತರೆ")
}

@Entity(tableName = "facility_photos")
data class FacilityPhoto(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String = FacilityCategory.CLASSROOM.name,
    val captionEnglish: String = "",
    val captionKannada: String = "",
    val photoUri: String = "",
    val addedAt: Long = System.currentTimeMillis()
)
