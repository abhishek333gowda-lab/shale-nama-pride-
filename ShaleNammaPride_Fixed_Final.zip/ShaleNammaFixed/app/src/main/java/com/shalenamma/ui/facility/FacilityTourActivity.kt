package com.shalenamma.ui.facility

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.shalenamma.ShaleNammaApp
import com.shalenamma.R
import com.shalenamma.data.model.FacilityCategory
import com.shalenamma.data.model.FacilityPhoto
import com.shalenamma.databinding.ActivityFacilityTourBinding
import com.shalenamma.utils.ViewModelFactory
import com.shalenamma.utils.toast

class FacilityTourActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFacilityTourBinding
    private lateinit var vm: FacilityViewModel
    private lateinit var adapter: FacilityAdapter
    private var pendingPhotoUri = ""

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { pendingPhotoUri = it.toString() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFacilityTourBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "🏫 Facility Tour"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory((application as ShaleNammaApp).repository)
        vm = ViewModelProvider(this, factory)[FacilityViewModel::class.java]

        adapter = FacilityAdapter(
            onDelete = { f ->
                AlertDialog.Builder(this)
                    .setTitle("Remove photo?")
                    .setPositiveButton("Remove") { _, _ -> vm.delete(f); toast("Removed") }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvFacilities.layoutManager = GridLayoutManager(this, 2)
        binding.rvFacilities.adapter = adapter

        vm.allFacilities.observe(this) { list ->
            adapter.submitList(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.btnAddFacility.setOnClickListener { showAddFacilityDialog() }
    }

    private fun showAddFacilityDialog() {
        pendingPhotoUri = ""
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_facility, null)
        val etCaptionEn = view.findViewById<EditText>(R.id.etCaptionEnglish)
        val etCaptionKn = view.findViewById<EditText>(R.id.etCaptionKannada)
        val spinner = view.findViewById<Spinner>(R.id.spinnerCategory)
        val btnPick = view.findViewById<android.widget.Button>(R.id.btnPickPhoto)

        val cats = FacilityCategory.values().map { it.displayEn }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
        btnPick.setOnClickListener { pickImage.launch("image/*") }

        AlertDialog.Builder(this)
            .setTitle("Add Facility Photo")
            .setView(view)
            .setPositiveButton("Add") { _, _ ->
                val capEn = etCaptionEn.text.toString().trim()
                val capKn = etCaptionKn.text.toString().trim()
                if (capEn.isEmpty()) { toast("Enter a caption"); return@setPositiveButton }
                val cat = FacilityCategory.values()[spinner.selectedItemPosition].name
                vm.save(FacilityPhoto(category = cat, captionEnglish = capEn,
                    captionKannada = capKn, photoUri = pendingPhotoUri))
                toast("✅ Facility photo added!")
            }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
