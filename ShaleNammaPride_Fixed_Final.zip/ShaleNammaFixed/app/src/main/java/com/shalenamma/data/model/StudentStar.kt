package com.shalenamma.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class StarCategory(val displayEn: String, val displayKn: String) {
    WEEK("Student of the Week", "ವಾರದ ವಿದ್ಯಾರ್ಥಿ"),
    SPORTS("Sports Winner", "ಕ್ರೀಡಾ ವಿಜೇತ"),
    ACADEMIC("Academic Topper", "ಶೈಕ್ಷಣಿಕ ಟಾಪರ್"),
    CULTURE("Cultural Star", "ಸಾಂಸ್ಕೃತಿಕ ತಾರೆ"),
    OTHER("Other Achievement", "ಇತರ ಸಾಧನೆ")
}

@Entity(tableName = "student_stars")
data class StudentStar(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentName: String = "",
    val studentNameKn: String = "",
    val className: String = "",
    val achievement: String = "",
    val achievementKn: String = "",
    val category: String = StarCategory.WEEK.name,
    val photoUri: String = "",
    val dateAwarded: String = "",      // "yyyy-MM-dd"
    val addedAt: Long = System.currentTimeMillis()
)
