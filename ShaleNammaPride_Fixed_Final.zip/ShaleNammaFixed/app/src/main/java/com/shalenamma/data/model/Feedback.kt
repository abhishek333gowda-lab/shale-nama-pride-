package com.shalenamma.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class FeedbackType(val displayEn: String, val displayKn: String) {
    PARENT("Parent", "ಪೋಷಕರು"),
    STUDENT("Student", "ವಿದ್ಯಾರ್ಥಿ"),
    TEACHER("Teacher", "ಶಿಕ್ಷಕರು"),
    COMMUNITY("Community", "ಸಮುದಾಯ")
}

@Entity(tableName = "feedback")
data class Feedback(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val senderName: String = "",
    val senderType: String = FeedbackType.PARENT.name,
    val message: String = "",
    val rating: Int = 5,               // 1–5 stars
    val isAnonymous: Boolean = false,
    val submittedAt: Long = System.currentTimeMillis()
)
