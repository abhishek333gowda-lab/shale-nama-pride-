package com.shalenamma.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "school_info")
data class SchoolInfo(
    @PrimaryKey val id: Int = 1,      // singleton row
    val schoolName: String = "",
    val schoolNameKn: String = "",
    val village: String = "",
    val taluk: String = "",
    val district: String = "",
    val principalName: String = "",
    val phoneNumber: String = "",
    val totalStudents: Int = 0,
    val totalTeachers: Int = 0,
    val established: String = "",
    val schoolPhotoUri: String = "",
    val motto: String = "",
    val mottoKn: String = ""
)
